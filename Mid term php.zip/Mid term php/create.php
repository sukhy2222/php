<?php

    // Create a new villain in the database

?>